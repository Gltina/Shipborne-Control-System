# coding=utf-8
# 放置一些共有数据变量

# 上位机接收数据指示符
# G_received_data_flag = False
